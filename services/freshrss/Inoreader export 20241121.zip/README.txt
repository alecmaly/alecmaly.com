This archive was exported from Inoreader on Thu, 21 Nov 2024 15:00:13 +0000
Most RSS Readers only need subscriptions.xml file, so if you get an error while uploading the zip file, try to extract subscriptions.xml and upload it directly.

Statistics:

Number of feeds: 201
Number of folders: 13
Number of tags: 0
Number of stars: 32
Number of saved web pages: 6
Export duration: 1 sec.

-- 
https://www.inoreader.com